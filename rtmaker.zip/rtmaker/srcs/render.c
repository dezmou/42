#include "rtmaker.h"

void write_file(t_env *e)
{
	FILE *fi = fopen("confmaker", "w");
	int i;
		printf("%d, %d, %d\n", (int)CAM.ori.x, (int)CAM.ori.y, (int)CAM.ori.z);
	fprintf(fi,"CAMERA %d %d %d ORIENTATION %d %d %d\n", (int)CAM.pos.x, (int)CAM.pos.y, -(int)CAM.pos.z, (int)CAM.ori.x, (int)CAM.ori.y, -(int)CAM.ori.z);
	i = 0;
	while (++i <= e->nbrobjs)
	{
		if (e->objs[i].type == I_SPHERE)
		{
			fprintf(fi, "SPHERE %d %d %d MATERIAL %f %f %f %f %f %f %f %f RADIUS 25\n", (int)e->objs[i].pos.x, (int)e->objs[i].pos.y, -(int)e->objs[i].pos.z, (float)e->objs[i].mat.red/255, (float)e->objs[i].mat.green/255, (float)e->objs[i].mat.blue/255, (float)e->objs[i].mat.reflection/100 ,(float)e->objs[i].mat.brillance/100,(float)e->objs[i].mat.bump_mapping/100 ,(float)e->objs[i].mat.refraction/100, (float)e->objs[i].mat.transparency/100);
			continue ;
		}
		if (e->objs[i].type == I_LIGHT)
		{
			fprintf(fi, "LIGHT %d %d %d INTENSITY 1 1 1\n", (int)e->objs[i].pos.x, (int)e->objs[i].pos.y, -(int)e->objs[i].pos.z);
			continue ;
		}
		if (e->objs[i].type == I_PLANE)
		{
			fprintf(fi, "PLANE %d %d %d MATERIAL 1 0 0 0 0 0 0 0 ORIENTATION %d %d %d\n", (int)e->objs[i].pos.x, (int)e->objs[i].pos.y, -(int)e->objs[i].pos.z, (int)e->objs[i].ori.x, (int)e->objs[i].ori.y, (int)e->objs[i].ori.z);
			continue ;
		}
		if (e->objs[i].type == I_CYLINDER)
		{
			fprintf(fi, "CYLINDER %d %d %d MATERIAL 1 0 0 0 0 0 0 ORIENTATION %d %d %d RADIUS 50\n", (int)e->objs[i].pos.x, (int)e->objs[i].pos.y, -(int)e->objs[i].pos.z, (int)e->objs[i].ori.x, (int)e->objs[i].ori.y, (int)e->objs[i].ori.z);
			continue ;
		}
		if (e->objs[i].type == I_CONE)
		{
			fprintf(fi, "CONE %d %d %d MATERIAL 1 0 0 0 0 0 0 0  ORIENTATION %d %d %d ANGLE 10\n", (int)e->objs[i].pos.x, (int)e->objs[i].pos.y, -(int)e->objs[i].pos.z, (int)e->objs[i].ori.x, (int)e->objs[i].ori.y, (int)e->objs[i].ori.z);
			continue ;
		}
	}
	fclose(fi);
}

void render(GTW *widget, t_env *e)
{
	write_file(e);
	system("./RTv1 confmaker");
	e->rendu = gtk_image_new_from_file("out.bmp");
	gtk_fixed_put(GTK_FIXED(e->fixed), e->rendu, 0, 0);
	refresh(e);
}
